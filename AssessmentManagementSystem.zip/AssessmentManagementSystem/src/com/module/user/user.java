package com.module.user;

import java.util.Scanner;

import javax.net.ssl.ManagerFactoryParameters;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.ejb.EntityManagerFactoryImpl;

import com.module.student.Assessment;

public class user {
	private static void main() {
		// TODO Auto-generated method stub

	
	EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=factory.createEntityManager();
	EntityTransaction et=em.getTransaction();
	et.begin();
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter trainee id");
	int id=scanner.nextInt();
	System.out.println("Enter trainee name");
	String name=scanner.next();
	System.out.println("Enter trainee module name");
	String module=scanner.next();
	System.out.println("Enter trainee mpt marks");
	int marks1=scanner.nextInt();
	System.out.println("Enter trainee mtt marks");
	int marks2=scanner.nextInt();
	System.out.println("Enter trainee assignment marks");
	int marks3=scanner.nextInt();
	Assessment assessment=new Assessment(id,name,module,marks1,marks2,marks3);
	((EntityManager) et).persist(assessment);
	et.commit();
	
	
	
	
	
	
	
	
	
	}
}
